// tests/getLocation.spec.ts
import { test, expect } from '@playwright/test';

const TOKEN = 'cWZSZGt4eW52dDNrX0xYVlozVHBZQlkxdGZjLUZQOHRnc3hOMDlOR0R6QQ==';

test('GET OCPI 2.2.1 location detail via Playwright', async ({ request }) => {
  const res = await request.get(
    'https://ocpi.liteonsg-csms.com/ocpi/cpo/2.2.1/locations/16befeb9-c43c-4301-a49e-d3229d846be3',
    {
      headers: {
        Authorization: `Token ${TOKEN}`,
        Accept: 'application/json',
      },
    }
  );

  // expect(res.ok()).toBeTruthy();  
  // expect(res.status()).toBe(200)        // 200 OK
  const location = await res.json();
  console.log(location);
  expect(location).toHaveProperty('name', 'LobbyF');
});
