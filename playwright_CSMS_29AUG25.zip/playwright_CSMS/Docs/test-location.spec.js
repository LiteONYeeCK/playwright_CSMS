// tests/getLocation.spec.js
import { test, expect } from '@playwright/test';

const TOKEN = 'cWZSZGt4eW52dDNrX0xYVlozVHBZQlkxdGZjLUZQOHRnc3hOMDlOR0R6QQ==';

test('GET OCPI location detail', async ({ request }) => {
  const res = await request.get(
    'https://ocpi.liteonsg-csms.com/ocpi/cpo/2.2.1/locations/16befeb9-c43c-4301-a49e-d3229d846be3',
    {
      headers: {
        Authorization: `Token ${TOKEN}`,
        Accept: 'application/json',
      },
    }
  );

  // expect(res.ok()).toBeTruthy();   // 200 OK
  expect(res.status()).toBe(200);
  const body = await res.json();   // <-- parse JSON once
  console.log('res:',res);
  console.log('body:',body);
  // console.log(await res.json());
  expect(body.data[0]).toHaveProperty('address', '151 Lorong Chuan'); // Ensure 'name' property exists in response
  // expect(res).toContain('151 Lorong Chuan'); // Check if '151 Lorong Chuan' is part of the response
});
